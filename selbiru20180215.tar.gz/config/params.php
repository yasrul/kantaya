<?php

return [
    'adminEmail' => 'kominfotik@ntbprov.go.id',
];
