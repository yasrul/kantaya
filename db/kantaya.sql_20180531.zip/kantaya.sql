-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 31, 2018 at 06:09 PM
-- Server version: 5.7.22-0ubuntu0.16.04.1
-- PHP Version: 5.6.36-1+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kantaya`
--

-- --------------------------------------------------------

--
-- Table structure for table `disposisi`
--

CREATE TABLE `disposisi` (
  `id` int(11) NOT NULL,
  `id_surat` int(11) NOT NULL,
  `id_pemberi` int(11) NOT NULL,
  `tgl_disposisi` datetime NOT NULL,
  `tgl_selesai` datetime DEFAULT NULL,
  `id_intruksi` tinyint(4) DEFAULT NULL,
  `pesan` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `disposisi_tujuan`
--

CREATE TABLE `disposisi_tujuan` (
  `id` int(11) NOT NULL,
  `id_disposisi` int(11) NOT NULL,
  `id_penerima` smallint(6) NOT NULL,
  `tgl_diterima` datetime DEFAULT NULL,
  `keterangan` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gender`
--

CREATE TABLE `gender` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `gender_name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gender`
--

INSERT INTO `gender` (`id`, `gender_name`) VALUES
(1, 'male'),
(2, 'female');

-- --------------------------------------------------------

--
-- Table structure for table `kecepatan_sampai`
--

CREATE TABLE `kecepatan_sampai` (
  `id` smallint(6) NOT NULL,
  `nama_kecepatan` varchar(50) NOT NULL,
  `nilai_kecepatan` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kecepatan_sampai`
--

INSERT INTO `kecepatan_sampai` (`id`, `nama_kecepatan`, `nilai_kecepatan`) VALUES
(1, 'Biasa', 10),
(2, 'Segera', 20),
(3, 'Amat Segera', 30);

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1436495090),
('m130524_201442_init', 1436495111);

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `first_name` text,
  `last_name` text,
  `birthdate` date DEFAULT NULL,
  `gender_id` smallint(5) UNSIGNED NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`id`, `user_id`, `first_name`, `last_name`, `birthdate`, `gender_id`, `created_at`, `updated_at`) VALUES
(1, 1, 'Yasrul', 'Abdullah', '1974-02-03', 1, '2015-07-30 16:21:39', '2015-07-30 16:21:39'),
(2, 3, 'Abdullah', 'Rawahah', '1979-05-16', 1, '2015-07-30 16:23:56', '2015-07-30 16:23:56'),
(3, 4, 'Fatimah', 'Sholihah', '1978-05-17', 2, '2015-07-30 16:25:15', '2015-07-30 16:25:15'),
(4, 5, 'Hamzah', 'Namira', '1980-08-27', 1, '2015-08-03 09:51:06', '2015-08-03 09:51:06');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `id` smallint(6) NOT NULL,
  `role_name` varchar(45) NOT NULL,
  `role_value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `role_name`, `role_value`) VALUES
(1, 'User', 10),
(2, 'Operator', 20),
(3, 'AdminSystem', 30);

-- --------------------------------------------------------

--
-- Table structure for table `status_akses`
--

CREATE TABLE `status_akses` (
  `id` tinyint(4) NOT NULL,
  `status_value` smallint(6) NOT NULL,
  `status_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status_akses`
--

INSERT INTO `status_akses` (`id`, `status_value`, `status_name`) VALUES
(1, 10, 'Draff'),
(2, 20, 'Aktif'),
(3, 30, 'Non Aktif');

-- --------------------------------------------------------

--
-- Table structure for table `status_reg`
--

CREATE TABLE `status_reg` (
  `id` smallint(6) NOT NULL DEFAULT '0',
  `status_name` varchar(30) NOT NULL,
  `status_value` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status_reg`
--

INSERT INTO `status_reg` (`id`, `status_name`, `status_value`) VALUES
(1, 'Masuk', 10),
(2, 'Keluar', 20),
(3, 'Draff Masuk', 30),
(4, 'Draff Keluar', 40);

-- --------------------------------------------------------

--
-- Table structure for table `status_surat`
--

CREATE TABLE `status_surat` (
  `id` int(11) NOT NULL,
  `status_name` varchar(50) NOT NULL,
  `status_value` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status_surat`
--

INSERT INTO `status_surat` (`id`, `status_name`, `status_value`) VALUES
(1, 'Sedia', 10),
(2, 'Terbaca', 20),
(3, 'Terhapus', 0);

-- --------------------------------------------------------

--
-- Table structure for table `status_tujuan`
--

CREATE TABLE `status_tujuan` (
  `id` tinyint(4) NOT NULL,
  `status_name` varchar(30) NOT NULL,
  `status_value` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status_tujuan`
--

INSERT INTO `status_tujuan` (`id`, `status_name`, `status_value`) VALUES
(1, 'Utama', 10),
(2, 'Tembusan', 20);

-- --------------------------------------------------------

--
-- Table structure for table `status_user`
--

CREATE TABLE `status_user` (
  `id` smallint(6) NOT NULL,
  `status_name` varchar(45) NOT NULL,
  `status_value` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status_user`
--

INSERT INTO `status_user` (`id`, `status_name`, `status_value`) VALUES
(1, 'Active', 10),
(2, 'Pending', 5);

-- --------------------------------------------------------

--
-- Table structure for table `surat`
--

CREATE TABLE `surat` (
  `id` int(11) NOT NULL,
  `id_dari` smallint(6) NOT NULL,
  `no_surat` varchar(255) NOT NULL,
  `tgl_surat` date NOT NULL,
  `perihal` varchar(255) NOT NULL,
  `lampiran` varchar(100) DEFAULT NULL,
  `kecepatan_sampai` smallint(6) DEFAULT NULL,
  `tingkat_keamanan` smallint(6) DEFAULT NULL,
  `id_pengirim` smallint(6) DEFAULT NULL,
  `pengirim_manual` varchar(100) DEFAULT NULL,
  `alamat_manual` varchar(255) DEFAULT NULL,
  `status_akses` tinyint(4) DEFAULT NULL,
  `doc_srcfilename` varchar(255) DEFAULT NULL,
  `doc_appfilename` varchar(255) DEFAULT NULL,
  `id_perekam` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `surat`
--

INSERT INTO `surat` (`id`, `id_dari`, `no_surat`, `tgl_surat`, `perihal`, `lampiran`, `kecepatan_sampai`, `tingkat_keamanan`, `id_pengirim`, `pengirim_manual`, `alamat_manual`, `status_akses`, `doc_srcfilename`, `doc_appfilename`, `id_perekam`) VALUES
(21, 13, '121', '2018-05-08', 'Perihal 121', 'Lampiran 121', 1, 1, 3, NULL, NULL, NULL, NULL, NULL, 3),
(22, 3, '45', '2018-05-08', 'Perihal 45', '', 1, 1, 5, '', '', NULL, NULL, NULL, 3),
(23, 3, '789', '2018-05-16', 'Surat 789', '', 1, 1, 3, NULL, NULL, NULL, NULL, NULL, 3),
(24, 9, '638', '2018-05-07', 'Perihal 638', '', 1, 1, 3, NULL, NULL, NULL, NULL, NULL, 3),
(25, 3, '956', '2018-05-15', 'Perihal', '', 1, 1, 3, NULL, NULL, NULL, NULL, NULL, 3);

-- --------------------------------------------------------

--
-- Table structure for table `surat_tujuan`
--

CREATE TABLE `surat_tujuan` (
  `id` int(11) NOT NULL,
  `id_surat` int(11) NOT NULL,
  `id_penerima` int(11) DEFAULT NULL,
  `penerima_manual` varchar(255) DEFAULT NULL,
  `alamat_manual` varchar(255) DEFAULT NULL,
  `status_tujuan` tinyint(4) DEFAULT NULL,
  `status_baca` tinyint(4) DEFAULT NULL,
  `tgl_diterima` datetime DEFAULT NULL,
  `tgl_diteruskan` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `surat_tujuan`
--

INSERT INTO `surat_tujuan` (`id`, `id_surat`, `id_penerima`, `penerima_manual`, `alamat_manual`, `status_tujuan`, `status_baca`, `tgl_diterima`, `tgl_diteruskan`) VALUES
(3, 21, 26, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 22, 3, NULL, NULL, NULL, NULL, '2018-05-15 00:00:00', NULL),
(5, 23, 6, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 24, 12, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 24, 15, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 25, 18, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 25, 7, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tingkat_keamanan`
--

CREATE TABLE `tingkat_keamanan` (
  `id` int(11) NOT NULL,
  `nama_tingkat` varchar(50) NOT NULL,
  `nilai_tingkat` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tingkat_keamanan`
--

INSERT INTO `tingkat_keamanan` (`id`, `nama_tingkat`, `nilai_tingkat`) VALUES
(1, 'Biasa', 10),
(2, 'Rahasia', 20),
(3, 'Sangat Rahasia', 30);

-- --------------------------------------------------------

--
-- Table structure for table `unit_kerja`
--

CREATE TABLE `unit_kerja` (
  `id` smallint(6) NOT NULL,
  `unit_kerja` varchar(255) NOT NULL,
  `id_induk` smallint(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unit_kerja`
--

INSERT INTO `unit_kerja` (`id`, `unit_kerja`, `id_induk`) VALUES
(1, 'Sekretaris Daerah', 0),
(2, 'Biro Pemerintahan', 1),
(3, 'Biro Hukum', 1),
(4, 'Biro Kesejahteraan Rakyat', 1),
(5, 'Biro Administrasi Perekonomian', 1),
(6, 'Biro Bina Adm Pengendalian Pembangunan dan LPBJP', 1),
(7, 'Biro Organisasi', 1),
(8, 'Biro Umum', 1),
(9, 'Biro Humas dan Protokol', 1),
(10, 'Sekretariat DPRD', 1),
(11, 'Inspektorat provinsi ', 1),
(12, 'Dinas Pendidikan dan Kebudayaan', 1),
(13, 'Dinas Kesehatan', 1),
(14, 'Dinas Pekerjaan Umum dan Penataan Ruang', 1),
(15, 'Dinas Perumahan dan Permukiman', 1),
(16, 'Dinas Sosial', 1),
(17, 'Dinas Tenaga Kerja dan Transmigrasi', 1),
(18, 'Dinas Pemberdayaan Masyarakat, Pemerintahan Desa, Kependudukan dan Catatan Sipil', 1),
(19, 'Dinas pemberdayaan Perempuan, Perlindungan anak, Pengendalian Penduduk dan Keluarga Berencana', 1),
(20, 'Dinas Ketahanan Pangan', 1),
(21, 'Dinas Lingkungan Hidup dan Kehutanan', 1),
(22, 'Dinas Perhubungan', 1),
(23, 'Dinas Komunikasi, Informatika dan Statistik', 1),
(24, 'Dinas Koperasi Usaha Kecil dan Menengah', 1),
(25, 'Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu', 1),
(26, 'Dinas Pemuda dan Olahraga', 1),
(27, 'Dinas Perpustakaan dan Kearsipan', 1),
(28, 'Dinas Kelautan dan Perikanan', 1),
(29, 'Dinas Pariwisata', 1),
(30, 'Dinas Pertanian dan Perkebunan', 1),
(31, 'Dinas Peternakan dan Kesehatan Hewan', 1),
(32, 'Dinas Energi dan Sumber Daya Mineral', 1),
(33, 'Dinas Perdagangan', 1),
(34, 'Dinas Perindustrian', 1),
(35, 'Satuan Polisi Pamong Praja', 1),
(36, 'Badan Perencanaan Pembangunan, Penelitian dan Pengembangan Daerah', 1),
(37, 'Badan pengelolaan Keuangan dan Aset Daerah', 1),
(38, 'Badan Pengelolaan Pendapatan Daerah', 1),
(39, 'Badan Pengembangan Sumberdaya Manusia Daerah', 1),
(40, 'Badan Kepegawaian Daerah', 1),
(41, 'Pelaksana Badan Penanggulangan Bencana Daerah', 1),
(42, 'Badan Penghubung Daerah', 1),
(43, 'Staf Ahli Bidang hukum dan Politik', 8),
(44, 'Staf Ahli Bidang Pemerintahan', 8),
(45, 'Staf Ahli Bidang Pembangunan', 8),
(46, 'Staf Ahli Bidang Kemasyarakatan dan Sumber Daya manusia', 8),
(47, 'Staf Ahli Bidang ekonomi dan Keuangan', 8),
(48, 'Asisten 1', 8),
(49, 'Asisten 2', 8),
(50, 'Asisten 3', 8),
(61, 'UPTD Balai Teknologi Informasi dan komunikasi Pendidikan', 1),
(62, 'UPTD Taman Budaya Sasambo', 1),
(63, 'UPTD museum Negeri', 1),
(64, 'UPTD Layanan Pendidikan Menengah dan Pendidikan Khusus, Pendidikan Layanan Khusus Bima', 1),
(65, 'UPTD Layanan Pendidikan Menengah dan Pendidikan Khusus, Pendidikan Layanan Khusus Dompu', 1),
(66, 'UPTD Layanan Pendidikan Menengah dan Pendidikan Khusus, Pendidikan Layanan Khusus Sumbawa', 1),
(67, 'UPTD Layanan Pendidikan Menengah dan Pendidikan Khusus, Pendidikan Layanan Khusus Sumbawa Barat', 1),
(68, 'UPTD Layanan Pendidikan Menengah dan Pendidikan Khusus, Pendidikan Layanan Khusus Lombok Timur', 1),
(69, 'UPTD Layanan Pendidikan Menengah dan Pendidikan Khusus, Pendidikan Layanan Khusus Lombok Tengah', 1),
(70, 'UPTD Layanan Pendidikan Menengah dan Pendidikan Khusus, Pendidikan Layanan Khusus Lombok Barat dan Mataram', 1),
(71, 'UPTD Layanan Pendidikan Menengah dan Pendidikan Khusus, Pendidikan Layanan Khusus Lombok Utara', 1),
(72, 'UPTD Balai Laboratorium Kesehatan Pengujian dan Kalibrasi', 1),
(73, 'UPTD Balai Kesehatan Mata Mataram', 1),
(74, 'UPTD Akademi Perawat Kesehatan', 1),
(75, 'UPTD Balai Pelatihan Kesehatan', 1),
(76, 'Balai pengujian material konstruksi ', 1),
(77, 'Balai pengelolaan sumber daya air dan hidrologi wilayah sungai pulau lombok ', 1),
(78, 'Balai pengelolaan sumber daya Air dan hidrologi wilayah sungai pulau sumbawa ', 1),
(79, 'Balai pemeliharaan jalan provinsi wilayah pulau lombok ', 1),
(80, 'Balai pemeliharaan jalan provinsi wilayah pulau sumbawa ', 1),
(81, 'Balai informasi infrastruktur wilayah', 1),
(82, 'Balai sosial asuhan anak "Generasi Harapan"', 1),
(83, 'Balai sosial perlindungan petiran anak "Sasambo Matupa"', 1),
(84, 'Balai sosial bina remaja " Karya Mandiri "', 1),
(85, 'Balai sosial karya wanita " Mirah Adi"', 1),
(86, 'Balai sosial bina laras " Mutmainah" ', 1),
(87, 'Balai sosial bina karya " Madani" ', 1),
(88, 'Balai sosial bina karya " Mandalika" ', 1),
(89, 'Balai sosial lanjut usia " Meci Angi" ', 1),
(90, 'Balai Latihan Kerja NTB', 1),
(91, 'Balai Hygene Perusahaan, Kesehatan dan Keselamatan Kerja', 1),
(92, 'Balai Latihan Masyarakat dan Transmigrasi', 1),
(93, 'Balai Pengawasan ketenagakerjaan Pulau Lombok', 1),
(94, 'Balai Pengawasan ketenagakerjaan Pulau Sumbawa', 1),
(95, 'UPTD Balai Sertifikasi Mutu Pangan', 1),
(96, 'Balai laboraturium lingkungan ', 1),
(97, 'Balai taman hutan raya nuraksa ', 1),
(98, 'KPH Rinjani barat pelanggan tastura ', 1),
(99, 'KPH Rinjani timur ', 1),
(100, 'KPH Sejorong mataiyang brangrea ', 1),
(101, 'KPH Pucak ngengas batulante ', 1),
(102, 'KPH Orang teluh balang beh ', 1),
(103, 'KPH Ropang ', 1),
(104, 'KPH Ampang plampang ', 1),
(105, 'KPH Tambora ', 1),
(106, 'KPH Ampang riwo soromandi ', 1),
(107, 'KPH toffo pajo madapangga rompo waworada ', 1),
(108, 'KPH Maria donggomasa ', 1),
(109, 'UPTD Bale ITE', 1),
(110, 'UPTD Balai Pendidikan dan Pelatihan Koperasi UKM', 1),
(111, 'Pelabuahan periakan labuhan Lombok', 1),
(112, 'Pelabuahan perikanan teluk Sentong ', 1),
(113, 'Balai pengembangan budidaya periakanan pantai ( BP BPP)sekotong ', 1),
(114, 'Balai pengembangan budidaya ikan air tawar (BP BIAT) Aik mel ', 1),
(115, 'balai kesehatan ikan dan lingkunngan perikanan Budidaya ', 1),
(116, 'Balai laboraturium pengujian dan penerapan mutu hasil kelautan dan perikanan ', 1),
(117, 'Balai kenservasi dan pengawasan sumber daya kelautan dan perikanan kawsan bima dompu ', 1),
(118, 'Balai konservasi dan pengawasan sumber daya kelautan dan perikanan kawasan sumbawa ', 1),
(119, 'Balai konservasi dan pengawasan sumber daya kelautan dan perikanan kawasan sumbawa ', 1),
(120, 'Balai pendidikan dan pelatihan kelautan dan perikanan tanjung luar ', 1),
(121, 'Balai perlindungan tanaman pertanian (BPTP)', 1),
(122, 'Balai benih induk pertanian(BBIP)', 1),
(123, 'Balai benih induk perkebunan (BBI-Bun', 1),
(124, 'Balai pengawasan dan sertifikasi benih pertanian (BPSB-P)', 1),
(125, 'Balai penyuluhan dan pengembangan sumber daya manusia pertanian dan perkebunan ', 1),
(126, 'Balai pengawasan dan sertifikasi benih perkebunan ', 1),
(127, 'Balai perlindungan tanaman perkebunan BPT -Bun ', 1),
(128, 'Sekolah menengah kejuruan pembangunan pertanian mataram SMK- PP Mataram ', 1),
(129, 'Sekolah menengah kejuruan pembangunan pertanian bima ', 1),
(130, 'Balai insimenasi buatan ', 1),
(131, 'Balai rumah sakit hewan dan laboraturium veteriner ', 1),
(132, 'Balai pembibitan ternak dan hijauan makanan ternak serading ', 1),
(133, 'Balai pengembangan dan pengolahan pakan ternak ruminansia ', 1),
(134, 'Balai ESDM Wilayah Sumbawa', 1),
(135, 'Balai Pengembangan Pelatihan dan Promosi Ekspor Daerah', 1),
(136, 'Balai Kemasan Produk Daerah', 1),
(137, 'Balai Pengelolaan Industri Daerah', 1),
(138, 'Unit Layanan Pemanfaatan Aset Daerah', 1),
(139, 'Unit Pengelolaan Islamic Center', 1),
(140, 'Unit Pelayanan Pajak Daerah  Mataram ', 1),
(141, 'Unit Pelayanan Pajak Daerah Praya ', 1),
(142, 'Unit Pelayanan Pajak Daerah Selong ', 1),
(143, 'Unit Pelayanan Pajak Daerah Sumbawa Besar ', 1),
(144, 'Unit Pelayanan Pajak Daerah Raba Bima ', 1),
(145, 'Unit Pelayanan Pajak Daerah Dompu ', 1),
(146, 'Unit Pelayanan Pajak Daerah Taliwang', 1),
(147, 'Unit Pelayanan Pajak Daerah Gerung', 1),
(148, 'Unit Pelayanan Pajak Daerah Tanjung ', 1),
(149, 'Unit Pelayanan Pajak Daerah Panda Bima', 1),
(150, 'Unit Pelayanan Penilaian Kompetensi', 1),
(151, 'UPT Sekretariat KORPRI Provinsi NTB', 1),
(161, 'Bagian Bina Pertanahan', 2),
(162, 'Bagian Otonomi Daerah', 2),
(163, 'Bagian Bina Administrasi Kewilayahan', 2),
(164, 'Kelompok Jabatan Fungsional Biro Pemerintahan', 2),
(165, 'Bagian Perundang-Undangan', 3),
(166, 'Bagian Bantuan Hukum dan Ham', 3),
(167, 'Bagian Pembinaan Hukum', 3),
(168, 'Kelompok Jabatan Fungsional Biro Hukum', 3),
(169, 'Bagian Keagamaan', 4),
(170, 'Bagian Kesejahteraan sosial', 4),
(171, 'Bagian Pendidikan, Kebudayaan, Kepemudaan dan Olahraga', 4),
(172, 'Kelompok Jabatan Fungsional Biro Kesra', 4),
(173, 'Bagian Produksi Daerah', 5),
(174, 'Bagian Penanaman Modal, BUMN dan Lembaga Keungan ', 5),
(175, 'Bagian Pengembangan Perekonomian', 5),
(176, 'Kelompok Jabatan Fungsional Biro Perekonomian', 5),
(177, 'Bagian Program dan Sekretariat LPBJP', 6),
(178, 'Bagian Administrasi Pembangunan  Ekonomi, Sosial, Budaya dan Kesejateraan Rakyat', 6),
(179, 'Bagian Administrasi Pembangunan Pembangunan Infrastuktur dan Tata Ruang', 6),
(180, 'Kelompok Jabatan Fungsional Biro APLPBJP', 6),
(181, 'Bagian Kelembagaan', 7),
(182, 'Bagian Tatalaksana dan Reformasi Birokrasi', 7),
(183, 'Bagian Analisis Formasi Jabatan dan Sumber Daya Aparatur ', 7),
(184, 'kelompok jabatan fungsional biro organisasi ', 7),
(185, 'Bagian Kesekretariatan dan Rumah Tangga', 8),
(186, 'Bagian Adm keuangan sekda', 8),
(187, 'Bagian Sarana Prasarana Sekda dan Rumah Jabatan', 8),
(188, 'kelompok jabatan fungsional biro Umum ', 8),
(189, 'Bagian Pemeritaan', 9),
(190, 'Bagian Dokumentasi', 9),
(191, 'Bagian Protokol', 9),
(192, 'Kelompok Jabatan Fungsional Biro Humas', 9),
(193, 'Bagian Persidangan dan Perundang-undangan', 10),
(194, 'Bagian Umum dan Humas ', 10),
(195, 'Bagian keuangan terdiri dari : ', 10),
(196, 'kelompok jabatan fungsioanal Sekretariat DPRD', 10),
(197, 'Sekretariat', 11),
(198, 'Inspektur pembantu I ', 11),
(199, 'Inspektur pemabantu II', 11),
(200, 'Inspektur Pembantu III', 11),
(201, 'Inspektur pembantu Khusus ', 11),
(202, 'kelompok jabatan fungsional Inspektorat', 11),
(203, 'Sekretariat', 12),
(204, 'Bagian Pembinaan sekolah menengah Atas', 12),
(205, 'bidang pembinaan sekoalh menengah kejuruan terdiri dari : ', 12),
(206, 'bidang pembinaan pendidikan khusus dan pendidikan layanan khusus terdiri dari: ', 12),
(207, 'bidang pembinaan ketenagaan ', 12),
(208, 'bidang pembinaan kebudayaan, terdiri dari ', 12),
(209, 'kelompok pejabat fungsional dinas pendidikan dan kebudayaan ', 12),
(210, 'Sekretariat', 13),
(211, 'Bidang kesehatan masyarakat', 13),
(212, 'Bidang pencegahan, pengendalian penyakit dan kesehatan lingkungan', 13),
(213, 'Bidang pelayanan kesehatan', 13),
(214, 'Bidang sumberdaya kesehatan', 13),
(215, 'Kelompok jabatan fungsional Dikes', 13),
(216, 'Sekertariat', 14),
(217, 'Bidang Sumberdaya Air', 14),
(218, 'Bidang Bina Marga', 14),
(219, 'Bidang Cipta Karya', 14),
(220, 'Bidang pengembangan infrastruktur wilayah ', 14),
(221, 'Bidang Tata Ruang', 14),
(222, 'Bidang Bina Konstruksi', 14),
(223, 'Kelompok Jabatan Fungsional PUPR', 14),
(224, 'Sekertariat ', 15),
(225, 'Bidang Perumahan', 15),
(226, 'Bidang pemukiman', 15),
(227, 'Bidang Bina Usaha Perumahan dan Pemukiman', 15),
(228, 'Kelompok Jabatan Fungsional Dinas PP', 15),
(229, 'Sekretariat', 16),
(230, 'Bidang perlindungan dan jaminan sosial', 16),
(231, 'Bidang pemeberdayaan sosial ', 16),
(232, 'Bidang rehabilitas sosial', 16),
(233, 'Bidang penangan fakir miskin ', 16),
(234, 'Kelompok jabatan fungsional ', 16),
(235, 'Sekretariat', 17),
(236, 'Bidang Penempatan dan Perluasan Kerja', 17),
(237, 'Bidang pelatihan dan produktivitas tenaga kerja', 17),
(238, 'Bidang pembinaan hubungan industri dan jaminan sosial tenaga kerja', 17),
(239, 'Bidang pembinaan pengawasan ketenaga kerjaan', 17),
(240, 'Bidang ketransmigrasian', 17),
(241, 'Kelompok jabatan fungsional ', 17),
(242, 'Sekertariat', 18),
(243, 'Bidang kelembagaan dan sosial budaya', 18),
(244, 'Bidang pemerintahan desa', 18),
(245, 'Bidang pengelolaan sumber daya alam dan teknologi tepat guna', 18),
(246, 'Bidang usaha ekonomi masyrakat', 18),
(247, 'Bidang kependudukan dan catatan sipil', 18),
(248, 'Kelompok jabatan fungsional ', 18),
(249, 'Sekretariat', 19),
(250, 'Bidang kesetaraan gender dan kualitas keluarga', 19),
(251, 'Bidang perlindungan hak perempuan', 19),
(252, 'Bidang pemenuhan hak anak', 19),
(253, 'Bidang pengendalian penduduk dan keluarga berencana', 19),
(254, 'Kelompok jabatan fungsional BP5KB', 19),
(255, 'Sekretariat', 20),
(256, 'Bidang ketersediaan dan kerawanan pangan', 20),
(257, 'Bidang distribusi dan cadangan pangan', 20),
(258, 'Bidang konsumsi dan keamanan pangan', 20),
(259, 'Kelompok jabatan Fungsional DKP', 20),
(260, 'Sekretariat', 21),
(261, 'Bidang analisis dan penegndalian lingkungan', 21),
(262, 'Bidang penataan dan penegelolaan llingkungan', 21),
(263, 'Bidang pengelolan hutan', 21),
(264, 'Bidang perlindungan hutan, konservasi sumber daya alam dan ekosistem', 21),
(265, 'Bidang rehabilitas dan pemberdayaan masyarakat', 21),
(266, 'Kelompok jabatan Fungsional ', 21),
(267, 'Sekretariat', 22),
(268, 'Bidang angkutan Darat ', 22),
(269, 'Bidang Pengelolaan Terminal', 22),
(270, 'Bidang perhubungan laut dan udara', 22),
(271, 'Kelompok jabatan fungsional Dishub', 22),
(272, 'Sekretaris', 23),
(273, 'Bidang informasi dan komunikasi publik', 23),
(274, 'Bidang pengelolaan teknologi informasi dan komunikasi', 23),
(275, 'Bidang persandian dan pengadaan secara elektronik', 23),
(276, 'Bidang statistik', 23),
(277, 'Kelompok jabatan fungsional Diskominfotik', 23),
(278, 'Sekretaris', 24),
(279, 'Bidang pembinaan koperasi', 24),
(280, 'Bidang pembinaan usaha kecil dan menengah', 24),
(281, 'Bidang pembinaan koperasi dan usaha simpan pinjam terdiridari ', 24),
(282, 'Bidang pengawasan koperasi', 24),
(283, 'Kelompok jabatan fungsional DISKOP UKM', 24),
(284, 'Sekretariat', 25),
(285, 'Bidang potensi dan promosi', 25),
(286, 'Bidang perizinan', 25),
(287, 'Bidang pengembangan dan kerja sama', 25),
(288, 'Bidang pengendalian', 25),
(289, 'Kelompok jabatan fungsional DPMPT', 25),
(290, 'Sekretariat', 26),
(291, 'Bidang kepemudaan', 26),
(292, 'Bidang keolahragaan', 26),
(293, 'Bidang Sarana dan Prasarana', 26),
(294, 'Jabatan fungsional Dispora', 26),
(295, 'Sekretariat', 27),
(296, 'Bidang pembinaan dan pengembangan perpustakaan', 27),
(297, 'Bidang deposit, dan informasi perpustakaan', 27),
(298, ' Bidang pengelolaan arsip dinamis', 27),
(299, 'Bidang pengelolaan Arsip statis', 27),
(300, 'Bidang pelayanan perpustakaan dan kearsipan', 27),
(301, 'Kelompok jabatan fungsional DPAP Arsip', 27),
(302, 'Sekretariat', 28),
(303, 'Bidang perikanan tangkap', 28),
(304, 'Bidang perikanan budi daya', 28),
(305, 'Bidang penguatan daya saing produk', 28),
(306, 'Bidang pengawasan pengelolaan sumber daya pesisir dan pulau- pulau kesil', 28),
(307, 'Klompok jabatan fungsional Dislutkan', 28),
(308, 'Sekretariat', 29),
(309, 'Bidang pemasaran pariwisata ', 29),
(310, 'Bidang pengembangan pariwisata', 29),
(311, 'Bidang kelembagaan pariwisata', 29),
(312, 'Bidang atraksi dan daya tarik pariwisata ', 29),
(313, 'Kelompok jabatan fungsional Dispar', 29),
(314, 'Sekretariat ', 30),
(315, 'Bidang tanaman pangan', 30),
(316, 'Bidang Holtikultura', 30),
(317, 'Bidang perkebunan', 30),
(318, 'Bidang sarana dan prasarana pertanian', 30),
(319, 'kelompok jabatan fungsional Distanbun', 30),
(320, 'Sekretariat', 31),
(321, 'Bidang kesehatan hewan', 31),
(322, 'Bidang pembibitan, produksi dan pakan ternak', 31),
(323, 'Bidang pengolahan dan pemasaran hasil peternakan', 31),
(324, 'Bidang kesehatan Masyarakat veteriner', 31),
(325, 'Kelompok jabatan Fungsional Disnakeswan', 31),
(326, 'Sekretariat', 32),
(327, 'Bidang geologi dan air tanah', 32),
(328, 'Bidang mineral dan batu bara', 32),
(329, 'Bidang energi', 32),
(330, 'Bidang ketenagalistrikan', 32),
(331, 'Kelompok jabatan fungsional DESDM', 32),
(332, 'Sekretariat', 33),
(333, 'Bidang stndarisasai dan perlindungan konsumen', 33),
(334, 'Bidang perdagangan dalam negeri', 33),
(335, 'Bidang perdagangan luar negeri', 33),
(336, 'jabatan Fungsional Disdag', 33),
(337, 'Sekretariat', 34),
(338, 'Bidang indstri agro', 34),
(339, 'Bidang industri logam, mesin, alat transportasi, elektronika dan telematika terdiri dari ', 34),
(340, 'Bidang industri kreatif, sandang dan kerajianan terdiri dari: ', 34),
(341, 'Kelompok jabatan Fungsional Disperin', 34),
(342, 'Sekretariat', 35),
(343, 'Bidang pembinaan masyarakat', 35),
(344, 'Bidang ketertiban umum dan ketentraman', 35),
(345, 'Bidang penegakan peraturan daerah', 35),
(346, 'Bidang pembianaan satuan perlindungan masyarakat', 35),
(347, 'Kelompok jabatan fungsional Polpp', 35),
(348, 'Sekretariat', 36),
(349, 'Bidang perencanaan wilayah dan pemabangunan infrastruktur', 36),
(350, 'Bidang perencanaan pembungan ekonomi', 36),
(351, 'Bidang peremcanaan pemabangunan sosial budaya', 36),
(352, 'Bidang penelitian dan pengembangan', 36),
(353, 'Bidang pemantauan, Evaluasi dan pengendalian perencanaan pemabangunan', 36),
(354, 'Kelompok jabatan fungsional Bappeda', 36),
(355, 'Sekretariat', 37),
(356, 'Bidang anggaran', 37),
(357, 'Bidang perbendaharaan', 37),
(358, 'Bidang akutansi dan pelaporan terdiri dari ', 37),
(359, 'Bidang pengelolaan barang milik daerah', 37),
(360, 'kelompok jabatan fungsional BPKAD', 37),
(361, 'Sekretariat', 38),
(362, 'Bidang perencanaan dan pengembangan', 38),
(363, 'Bidang pajak daerah', 38),
(364, 'Bidang retribusi, dana perimbangan dan pendapatan lainya', 38),
(365, 'Bidang pengendalian dan pembinaan', 38),
(366, 'Kelompok jabatan fungsional Bappenda', 38),
(367, 'Sekretariat', 39),
(368, 'Bidang sertifikasi dan pengelola kelembagaan', 39),
(369, 'Bidang pengembangan kompetensi teknis', 39),
(370, 'Bidang pengembangan kompetensi Manajerial dan fungsional', 39),
(371, 'Kelompok jabatan fungsional BPSDM', 39),
(372, 'Sekretaris BKD', 40),
(373, 'Bidang Mutasi Pegawai', 40),
(374, 'Bidang Pengembangan dan Pembinaan Pegawai', 40),
(375, 'Bidang Informasi Kepegawaian', 40),
(376, 'Jabatan Fungsional BKD', 40),
(377, 'Sekretariat', 41),
(378, 'Bidang Pencegahan dan Kesiapsiagaan', 41),
(379, 'Bidang Kedaruratan dan Logistik', 41),
(380, 'Bidang Rehabilitasi dan Rekonstruksi', 41),
(381, 'Jabatan Fungsional BPBD', 41),
(382, 'Jabatan Fungsional Badan Penghubung', 42),
(401, 'Subbag Pengawasan dan Pengendalian Pertanahan', 161),
(402, 'Subbag Fasilitasi Tanah Bermasalah', 161),
(403, 'Subbag Tata Usaha Biro', 161),
(404, 'Subbag Penataan Daerah', 162),
(405, 'Subbag Fasilitasi Kepala Daerah dan DPRD', 162),
(406, 'Subbag Peningkatan Kapasitas Daerah', 162),
(407, 'Subbag Pembinaan Wilayah', 163),
(408, 'Subbag Fasilitasi Kebijakan Ketentraman Ketertiban, Perlindungan Masyarakat dan Kebencanaan', 163),
(409, 'Subbag Dekonsentrasi dan Tugas Pembantuan', 163),
(410, 'PTT', 2),
(411, 'Subbag Rancangan Peraturan Daerah', 165),
(412, 'Subbag Rancangan Peraturan Kepala Daerah', 165),
(413, 'Subbag Rancangan Ketetapan', 165),
(414, 'Subbag Sengketa Hukum', 166),
(415, 'Subbag Penyusunan Naskah Perjanjian', 166),
(416, 'Subbag HAM dan HAKI', 166),
(417, 'Subbag Penyuluhan Hukum', 167),
(418, 'Subbag Dokumentasi Hukum', 167),
(419, 'Subbag Tata Usaha Biro', 167),
(420, 'PTT', 3),
(421, 'Subbag Bagian Pembinaan Keagamaan dan Kerukunan Umat Beragama', 169),
(422, 'Subbag Sarana dan Prasarana Keagamaan', 169),
(423, 'Subbag Pendidikan Keagamaan', 169),
(424, 'Subbag Kesehatan dan Pengendalian Penduduk', 170),
(425, 'Subbag sosial, Pemberdayaan Perempuan dan Perlindungan Anak', 170),
(426, 'Subbag Tenaga Kerja, Transmigrasi dan Pemberdayaan Masyarakat', 170),
(427, 'Subbag Pendidikan dan Kebudayaan', 171),
(428, 'Subbag Kepemudaan dan Olahraga', 171),
(429, 'Subbag Tata Usaha', 171),
(430, 'PTT', 4),
(431, 'Subbag Pertambangan dan Energi ', 173),
(432, 'Subbag Pertanian, Kehutanan, Kelautan dan Perikanan ', 173),
(433, 'Subbag Perdagangan dan Perindustrian ', 173),
(434, 'Subbag Penanaman Modal dan Promosi ', 174),
(435, 'Subbag Badan Usaha Milik Daerah ', 174),
(436, 'Subbag Lemabaga Keuangan, Koperasi dan Usaha Kecil Menengah ', 174),
(437, 'Subbag Data dan Statistik Perekonomian ', 175),
(438, 'Subbag Periwisata dan Perhubungan ', 175),
(439, 'Subbag Tata Usaha Biro ', 175),
(440, 'PTT', 5),
(441, 'Subbag Program dan Pelaporan ', 177),
(442, 'Subbag Pelayanan ', 177),
(443, 'Subbag Tata Usaha ', 177),
(444, 'Subbag Pembangunan Ekonomi ', 178),
(445, 'Subbag Pembengunan Sosial Budaya ', 178),
(446, 'Subbag Pembangunan Kesejahteraan Rakyat ', 178),
(447, 'Subbag Pembengunan Perumahann dan Kawasan Pemukiman ', 179),
(448, 'Subbag Pembangunan Sumber Daya Air dan Lingkungan Hidup ', 179),
(449, 'Subbag Pembangunan Perhubungan Dan Tata Ruang', 179),
(450, 'PTT', 6),
(451, 'Subbag Analisis Kelembagaan ', 181),
(452, 'Subbag Fasilitas dan Monitoring dan Evaluasi Kelembagaan ', 181),
(453, 'Subbag Analisis Kelembagaan UPT Daerah dan Fasilitas Kelembagaan Pusat', 181),
(454, 'Subbag Standarisasi dan Budaya Kerja ', 182),
(455, 'Subbag Akuntabilitas dan Evaluasi Kinerja ', 182),
(456, 'Subbag Reformasi Birokrasi dan Pelayanan Publik ', 182),
(457, 'Subbag Analisis dan Evaluasi Jabatan ', 183),
(458, 'Subbag sumber Daya Aparatur ', 183),
(459, 'Subbag Tata Usaha ', 183),
(460, 'PTT', 7),
(461, 'Subbag Rumah tangga Pimpinan', 185),
(462, 'Subbag Arsip dan ekspedisi', 185),
(463, 'Subbag tata Usaha, kepegawaian dan Perjalanan', 185),
(464, 'Subbag Tata Usaha sekda, Asisten dan Staf Ahli Gub', 185),
(465, 'Subbag perencanaan', 186),
(466, 'Subbag Penatausahaan Keuangan', 186),
(467, 'Subbag akuntasi dan Pelaporan', 186),
(468, 'Subbag Sarana Perkantoran', 187),
(469, 'Subbag Prasarana Perkantoran', 187),
(470, 'Subbag Sarana Prasarana Rumah Jabatan', 187),
(471, 'PTT', 8),
(472, 'Subbag hubungan Media', 189),
(473, 'Subbag Pengelolaan Data dan Naskah Pimpinan', 189),
(474, 'Subbag Peliputan', 189),
(475, 'Subbag Pengelolaan Dokumen dan Perpustakaan', 190),
(476, 'Subbag Produksi', 190),
(477, 'Subbag Tata Usaha', 190),
(478, 'Subbag Tata Usaha Pimpinan', 191),
(479, 'Subbag Tamu Daerah', 191),
(480, 'Subbag Acara', 191),
(481, 'PTT', 9),
(482, 'Subbag Rapat dan Risalaha', 193),
(483, 'Subbag Alat Kelengkapan Dewan dan Fraksi', 193),
(484, 'Subbag Perundang-undangan, Dokumentasi dan perpustakaan', 193),
(485, 'Subbag urusan dalam dan pengamanan dalam ', 194),
(486, 'Subbag humas, protokol dan perjalanan ', 194),
(487, 'Subbag tata usaha ', 194),
(488, 'Subbag perencanaan ', 195),
(489, 'Subbag tata usaha keuangan ', 195),
(490, 'Subbag verifikasi dan pembukuan ', 195),
(491, 'PTT', 10),
(492, 'Subbag Program ', 197),
(493, 'Subbag Analisa dan Evaluasi Hasil Pengawasan ', 197),
(494, 'Subbag Umum dan Keuangan ', 197),
(495, 'PTT', 11),
(496, 'Subbag program dan Keuanagn', 203),
(497, 'Subbag Umum dan Keuangan ', 203),
(498, 'Subbag Penyelenggaraan Tugas Pembantuan', 203),
(499, 'seksi kurikulum sekolah menengah atas ', 204),
(500, 'seksi Peserta Didik Sekolah menengah Atas', 204),
(501, 'seksi kelembagaan dan sarana prasarana sekolah menengah atas ', 204),
(502, 'seksi kurikulum sekolah menengah kejuruan ', 205),
(503, 'seksi peserta didik sekoalh menengah kejuruan dan ', 205),
(504, 'seksi kelembagaan dan sarana prasarana sekolah menengah kejuruan ', 205),
(505, 'seksi kurikulum pendidikan khusus dan pendidikan layanan khusus', 206),
(506, 'seksi peserta didik dan pembangunan karakater pendidikan khusus dan pendidkan layanan  khusus; dan ', 206),
(507, 'seksi kelembagaan dan sarana prasarana pendidikan khusus dan pendidiakn khusus ', 206),
(508, 'seksi guru dan ketengaan pendidikan sekolah menengah atas dan pendidikan khusus ', 207),
(509, 'seksi guru dan tenaga kependidikan sekolah menengah kejuruan ; dan ', 207),
(510, 'seksi tenaga kebudayaan ', 207),
(511, 'seksi cagar budaya dan museum ', 208),
(512, 'seksi sejarah dan tradisi ', 208),
(513, 'seksi kesenian ', 208),
(514, 'PTT', 12),
(515, 'Subbag Program ', 210),
(516, 'Subbag Keuangan ', 210),
(517, 'Subbag Umum ', 210),
(518, 'Seksi kesehatan keluarga ', 211),
(519, 'Seksi gizi masyarakat ', 211),
(520, 'Seksi Promosi kesehatan dan Pemberdayaan masyarakat ', 211),
(521, 'Seksi survellans epidemiologi, imunisasi dan kesehatan bencana ', 212),
(522, 'Seksi pencegahan dan pengendalian penyakit; dan ', 212),
(523, 'Seksi kesehatan lingkungan ', 212),
(524, 'Seksi pelayanan kesehatan primer dan kesehatan tradisional ', 213),
(525, 'Seksi pelayanan kesehatan rujukan ', 213),
(526, 'Seksi sakreditasi dan jaminan kesehatan ', 213),
(527, 'Seksi kefarmasian, makanan, minuman dan alat kesehatan ', 214),
(528, 'Seksi pengembangan sumberdaya manusia kesehatan ', 214),
(529, 'Seksi data, informasi, penelitian dan pengembangan kesehatan ', 214),
(530, 'PTT', 13),
(531, 'Subbag Program ', 216),
(532, 'Subbag Keuangan', 216),
(533, 'Subbag Umum ', 216),
(534, 'Seksi perencanaan teknis sumber daya air ', 217),
(535, 'Sumber pemanfaatan sumberdaya air', 217),
(536, 'Seksi konservasi sumber daya air ', 217),
(537, 'Seksi perencanaan teknis jalan ', 218),
(538, 'Seksi pembangunan jalan', 218),
(539, 'Seksi pembinaan teknik jalan ', 218),
(540, 'Seksi perencanaan teknis ', 219),
(541, 'Seksi air Bersih dan penyehatan lingkungan ', 219),
(542, 'Seksi tata banguna dan permukiman ', 219),
(543, 'Seksi pengembangan keterpaduan antar kawasan ', 220),
(544, 'Seksi pengembangan keterpaduan antar sektor', 220),
(545, 'Seksi pengembangan keterpaduan infrastruktur ', 220),
(546, 'Seksi perencanaan tata ruang ', 221),
(547, 'Seksi pemanfaatan ruang', 221),
(548, 'Seksi pengendalian pemanfaatan ruang ', 221),
(549, 'Seksi pengaturan ', 222),
(550, 'Seksi pemeberdayaan jasa konstruksi', 222),
(551, 'Seksi pengawasan jasa konstruksi ', 222),
(552, 'PTT', 14),
(553, 'Subbag program dan keuangan ', 224),
(554, 'Subbag Umum', 224),
(555, 'Seksi perencanaan teknis perumahan ', 225),
(556, 'Seksi perumahan formal ', 225),
(557, 'Seksi perumahan swadaya ', 225),
(558, 'Seksi perencanaan pemukiman ', 226),
(559, 'Seksi penataan kawsan kumuh ', 226),
(560, 'Seksi prasarana sarana dan utilitas ', 226),
(561, 'Seksi pengendalian dan Pengawasan', 227),
(562, 'Seksi Penelitian dan Pengembangan', 227),
(563, 'Seksi Kerjasama Pembangunan Perumahan dan Permukiman', 227),
(564, 'PTT', 15),
(565, 'Subbag program ', 229),
(566, 'Subbag Keuangan', 229),
(567, 'Subbag Umum', 229),
(568, 'Seksi perlindungan sosial korban bencana alam ', 230),
(569, 'Seksi perlindungan sosial korban bencana sosial dan ', 230),
(570, 'Seksi jaminan sosial keluarga ', 230),
(571, 'Seksi pemeberdayaan sosiala perseorangan, keluarga, masyarakat, dan kelembagaan sosial ', 231),
(572, 'Seksi pemberdayaan pengelolaan sumber dan dan bantuan sosial ', 231),
(573, 'Seksi kepahlawanan dan penyuluhan sosial ', 231),
(574, 'Seksi rehabilitas sosial penyandang disabilitas dan korban napza ', 232),
(575, 'Seksi rahabilitas sosial tuna sosial dan korban peradangan orang ', 232),
(576, 'Seksi rehabilitas sosial anak dan lanjut usia ', 232),
(577, 'Seksi penanganan fakir miskin perkotaan ', 233),
(578, 'Seksi penanganan fakir miskin predesaan dan ', 233),
(579, 'Seksi penanganan fakir miskin peisisir dan pualau -pulau kecil ', 233),
(580, 'PTT', 16),
(581, 'Subbag Program', 235),
(582, 'subbag Keuangan', 235),
(583, 'Subbag Umum', 235),
(584, 'Seksi informasi pasar kerja ', 236),
(585, 'Seksi penempatan tenaga kerja dan pembina tenaga kerja asing', 236),
(586, 'Seksi perlauasan kesempatan kerja ', 236),
(587, 'Seksi pembinaan instruktur dan kelembagaan ', 237),
(588, 'Seksi pemagangan', 237),
(589, 'Seksi pembinaan pelatihan dan produktivitas tenaga kerja ', 237),
(590, 'Seksi syarat kerja, kelembagaan dan kerja sama hubungan industrial ', 238),
(591, 'Seksi pengupahan dan jamimnan sosial tenaga kerja ', 238),
(592, 'Seksi penecegahan dan penyelesaian pesrselisihan hubungan industrial ', 238),
(593, 'Seksi norma ketenagakerjaan ', 239),
(594, 'Seksi keselamatan dan kesehatan kerja ', 239),
(595, 'Seksi pemeberdayaan pengawasan dan penegakan hukum ', 239),
(596, 'Seksi penyedian areal dan pembinaan penegakan transmigrasi ', 240),
(597, 'Seksi perpindahan dan penempatan transmigrasi ', 240),
(598, 'Seksi pembinaan dan pengembangan kawasan transmigrasi ', 240),
(599, 'PTT', 17),
(600, 'Subbag Program', 242),
(601, 'subbag Keuangan', 242),
(602, 'Subbag Umum', 242),
(603, 'Seksi sosial budaya masyarakat ', 243),
(604, 'Seksi kelembagaan masyarakat desa ', 243),
(605, 'Seksi pengembangan kapasitas dan informasi desa ', 243),
(606, 'Seksi pengembangan kapasitas aparatur pemerintah desa dan bpd ', 244),
(607, 'Seksi penataan desa dan kelembagaan pemerintahan desa ', 244),
(608, 'Seksi evalluasi perekembangan desa dan kelurahan ', 244),
(609, 'Seksi pengelolaan sumber daya alam ', 245),
(610, 'Seksi teknologi tepat guna ', 245),
(611, 'Sekdi sarana dan prasarana ', 245),
(612, 'Seksi ekonomi  masyarakat dan kelompok msyarakat ', 246),
(613, 'Seksi pengembangan produksi dan pemasaran ', 246),
(614, 'Seksi kerja sama antar desa ', 246),
(615, 'Seksi kependudukan ', 247),
(616, 'Seksi catatn sipil dan ', 247),
(617, 'Seksi informasi administrasi kependudukan ', 247),
(618, 'PTT', 18),
(619, 'Subbag Program', 249),
(620, 'Subbag Keuangan ', 249),
(621, 'Subbag Umum ', 249),
(622, 'Seksi ekonomi ', 250),
(623, 'Seksi pendidikan, kesehatan, pembangaunan kelauarga', 250),
(624, 'Seksi politik, hukum, pertahanan keamanan, lingkungan, data dan informasi ', 250),
(625, 'Seksi perlindungan tindak kekerasan ', 251),
(626, 'Seksi perlindungan situasi khusus dan darurat', 251),
(627, 'Seksi penguatan kelembagaan dan perlindungan ', 251),
(628, 'Seksi pemenuhan hak anak ', 252),
(629, 'Seksi perlindungan anak dari kekerasan dan eksploitasi', 252),
(630, 'Seksi perlindungan anak dalam sistuasi khusus dan darurat ', 252),
(631, 'Seksi pengendalian penduduk ', 253),
(632, 'Seksi kelaurga berencana dan kesehatan reproduksi', 253),
(633, 'Seksi kelaarga sejahtera ', 253),
(634, 'PTT', 19),
(635, 'Subbag Program ', 255),
(636, 'Subbag Keuangan ', 255),
(637, 'Subbag Umum ', 255),
(638, 'Seksi ketersediaan pangan', 256),
(639, 'Seksi kerawanan pangan ', 256),
(640, 'Seksi ditribusi pangan', 257),
(641, 'Seksi Cadangan pangan ', 257),
(642, 'Seksi konsumsi pangan', 258),
(643, 'Seksi keamanan pangan ', 258),
(644, 'PTT', 20),
(645, 'Subbag Program ', 260),
(646, 'Subbag Keuangan ', 260),
(647, 'Subbag Umum', 260),
(648, 'Seksi analisis dampak lingkungan ', 261),
(649, 'Seksi penegendalian pencemaran', 261),
(650, 'Seksi kerusakan lingkungan ', 261),
(651, 'Seksi penataan lingkungan ', 262),
(652, 'Seksi peningkatan kapasitas lingkungan hidup', 262),
(653, 'Seksi pengelolaan Sampah dan Limbah B3 ', 262),
(654, 'Seksi perencanaan dan tata hutan ', 263),
(655, 'Seksi usaha kehutanan ', 263),
(656, 'Seksi pengolahan, pemasaran dan iuran ', 263),
(657, 'Seksi pencegahan dan pengamanan hutan ', 264),
(658, 'Seksi penegakan hukum ', 264),
(659, 'Seksi keonservasi dan pelestarian Sumber daya Alam dan ekosistem ', 264),
(660, 'Seksi rehabilitas hutan dan lahan ', 265),
(661, 'Seksi pengelolaan daerah aliran sungai', 265),
(662, 'Seksi pemberdayaan dan penyuluhan ', 265),
(663, 'PTT', 21),
(664, 'Subbag Program ', 267),
(665, 'Subbag Keuangan ', 267),
(666, 'Subbag Umum ', 267),
(667, 'Seksi sarana prasarana transportasi darat ', 268),
(668, 'Seksi keselamatan', 268),
(669, 'Seksi pengendalian angkutan darat ', 268),
(670, 'Seksi perencanaan terminal ', 269),
(671, 'Seksi operasional terminal ', 269),
(672, 'Seksi pengawasan terminal ', 269),
(673, 'Seksi angkutan perairan ', 270),
(674, 'Seksi kepelabuhanan', 270),
(675, 'Seksi manajemen dan keselamatan transportasi laut dan udara ', 270),
(676, 'PTT', 22),
(677, 'Subbag Program ', 272),
(678, 'Subbag Keuangan ', 272),
(679, 'Subbag Umum ', 272),
(680, 'Seksi pengelolaan dan dokumentasi informasi ', 273),
(681, 'Seksi publikasi ', 273),
(682, 'Seksi kelembagaan ', 273),
(683, 'Seksi aplikasi teknologi informasi dan komunikasi ', 274),
(684, 'Seksi infrastuktur teknologi informasi dan komunikasi ', 274),
(685, 'Seksi tata kelola teknologi informasi dan komunikasi ', 274),
(686, 'Seksi persandian dan keamanan informasi ', 275),
(687, 'Seksi layanan pengadaan secara elektronik ', 275),
(688, 'Seksi telekomunikasi dan pengendalian ', 275),
(689, 'Seksi statistik sosial ', 276),
(690, 'Seksi statistik ekonomi ', 276),
(691, 'Seksi statistik sumber daya alam dan infrastruktur ', 276),
(692, 'PTT', 23),
(693, 'Sub bagian program ', 278),
(694, 'Sub bagian keuangan', 278),
(695, 'Sub bagian umum ', 278),
(696, 'Seksi kelembagaan koperasi ', 279),
(697, 'Seksi pengembangan usaha koperasi ', 279),
(698, 'Seksi penilain akuntabilitas koperasi ', 279),
(699, 'Seksi pemasaran dan jaringan usaha kecil  dan menengah ', 280),
(700, 'Seksi pengembangan usaha kecil dan menengah', 280),
(701, 'Seksi stndarisasi dan legalitas usaha kecil dan menengah ', 280),
(702, 'Seksi kelembagaan dan perizinan koperasi dan usaha simpan pinjam ', 281),
(703, 'Seksi fasilitas pembiayaan koperasi usaha simpan pinjam', 281),
(704, 'Seksi pembinaan koperasi dan usaha simpan pinjam syari\'ah ', 281),
(705, 'Seksi pemeriksaan kelembagaan ', 282),
(706, 'Seksi pemeriksaan usaha', 282),
(707, 'Seksi seksi kepatuhan dan penerapan sanksi ', 282),
(708, 'PTT', 24),
(709, 'Subbag Program ', 284),
(710, 'Subbag keuangan', 284),
(711, 'Subbag Umum ', 284),
(712, 'Seksi potensi ', 285),
(713, 'Seksi pameran dan sarana promosi', 285),
(714, 'Seksi fasilitas promosi ', 285),
(715, 'Seksi pelayanan aplikasi dan informasi ', 286),
(716, 'Seksi pelayanan perizinan', 286),
(717, 'Seksi fasilitas perizinan ', 286),
(718, 'Seksi pemberdayaan usaha dan investasi ', 287),
(719, 'Seksi fasilitas kerjasama antar dunia usaha', 287),
(720, 'Seksi fasilitas kerjasama Antar pemerintah ', 287),
(721, 'Seksi pendataan ', 288),
(722, 'Seksi pembinaan dan pengawasan', 288),
(723, 'Seksi Evaluasi dan pelaporan ', 288),
(724, 'PTT', 25),
(725, 'Sub bagain program ', 290),
(726, 'Sub bagian keuangan ', 290),
(727, 'Sub bagian umum ', 290),
(728, 'Seksi pengembangan pemuda ', 291),
(729, 'Seksi pemberdayaan pemuda ', 291),
(730, 'Seksi kepramukaan dan kepemimpinan pemuda ', 291),
(731, 'Seksi Pembudayaan Olahraga', 292),
(732, 'Seksi Peningkatan Prestasi Olahraga', 292),
(733, 'Seksi Pembinaan Olahraga Pelajar', 292),
(734, 'Seksi sarana prasarana kepemudaan ', 293),
(735, 'Seksi sarana prasarana keolahragaan ', 293),
(736, 'PTT', 26),
(737, 'Sub bagian program ', 295),
(738, 'Sub bagian keuangan', 295),
(739, 'Sub bagian umum ', 295),
(740, 'Seksi pembinaan perpustakaan ', 296),
(741, 'Seksi pengembangan minat baca', 296),
(742, 'Seksi kelembagaan dan kerja sama. ', 296),
(743, 'Seksi deposit perpustakaan ', 297),
(744, 'Seksi pelestarian perpustakaan', 297),
(745, 'Seksi informasi perpustakaan ', 297),
(746, 'Seksi pembinaan kearsipaan ', 298),
(747, 'Seksi pengelolaan arsip dinamis', 298),
(748, 'Seksi penilaian dan penyusustan. ', 298),
(749, 'Seksi penulusuran, akusisi dan penyelamatan kearsipan ', 299),
(750, 'Seksi pengolahan, perwatan dan pelestarian kearsipan', 299),
(751, 'Seksi informasi kearsipan ', 299),
(752, 'Seksi otomatisasi perpustakaan dan kearsipan ', 300),
(753, 'Seksi pelayanan perpustakaan ', 300),
(754, 'Seksi pelayanan kearsipan ', 300),
(755, 'PTT', 27),
(756, 'Sub bagian program ', 302),
(757, 'Sub bagian keuangan ', 302),
(758, 'Sub bagian umum ', 302),
(759, 'Seksi pengelolaan sumber daya ikan dan pengendalian penangkapan ikan ', 303),
(760, 'Seksi pelabuhan perikanan', 303),
(761, 'Seksi kapal perikanan, Alat penangkapan ikan dan kenelayanan ', 303),
(762, 'Seksi perbenihan ', 304),
(763, 'Seksi produksi budidaya ', 304),
(764, 'Seksi usaha budidaya ', 304),
(765, 'Seksi bina mutu, diversifikasi produk kelautan dan perikanan ', 305),
(766, 'Seksi akses pasar dan promosi ', 305),
(767, 'Seksi usaha dan logistik ', 305),
(768, 'Seksi tataruang laut dan pengelolaan perairan pesisir ', 306),
(769, 'Seksi pemeberdayaan masyarakat dan pelestarian sumber daya perairan pesisir dan pulau kecil ', 306),
(770, 'Seksi pengawasan sumber daya kelautan dan perikanan ', 306),
(771, 'PTT', 28),
(772, 'Sub bagian program ', 308),
(773, 'Sub bagian keuangan', 308),
(774, 'Sub bagian umum ', 308),
(775, 'Seksi analisa pasar ', 309),
(776, 'Seksi promosi pariwisata ', 309),
(777, 'Seksi kerjasama pariwisata ', 309),
(778, 'Seksi produk wisata ', 310),
(779, 'Seksi usaha pariwisata', 310),
(780, 'Seksi pengembangan infrastruktur pariwisata ', 310),
(781, 'Seksi pendidikan dan pelatihan tenaga pariwisata ', 311),
(782, 'Seksi bimbingan masyarakat pariwisata ', 311),
(783, 'Seksi pengembangan atraksi dan daya tarik wisata ', 312),
(784, 'Seksi pengembangan industri kraetif', 312),
(785, 'Seksi atraksi Budaya ', 312),
(786, 'PTT', 29),
(787, 'Sub bagian program ', 314),
(788, 'Sub bagian keuangan ', 314),
(789, 'Sub bagian umum ', 314),
(790, 'Seksi perbenihan dan perlindungan tanaman pangan ', 315),
(791, 'Seksi produksi tanaman pangan ', 315),
(792, 'Seksi pengolahan dan pemasaran tanaman pangan ', 315),
(793, 'Seksi perbenihan dan perlindungan holtikultura ', 316),
(794, 'Seksi produksi tanaman holtikultura', 316),
(795, 'Seksi pengolahan dan pemasaran holtikultura', 316),
(796, 'Seksi perbenihan dan perlindungan perkebunan ', 317),
(797, 'Seksi produksi tanaman perkebunan', 317),
(798, 'Seksi pengolahan dan pemasaran hasil perkebunan ', 317),
(799, 'Seksi lahan, irigasi dan pembiayaan ', 318),
(800, 'Seksi pupuk dan pestisida', 318),
(801, 'Seksi alat dan mesin pertanian ', 318),
(802, 'PTT', 30),
(803, 'Sub bagain program ', 320),
(804, 'Sub bagian keuangan', 320),
(805, 'Sub bagian umum ', 320),
(806, 'Seksi pengamatan penyakit hewan ', 321),
(807, 'Seksi pencegahan dan Pemberantasan penyakit hewan', 321),
(808, 'Seksi pengawasan obat hewan dan pelayanan kesehatan hewan ', 321),
(809, 'Seksi pembibitan ternak ', 322),
(810, 'Seksi produksi sarana dan prasarana peternakan dan ', 322),
(811, 'Seksi pakan ', 322),
(812, 'Seksi investasi dan pengembangan usaha ', 323),
(813, 'Seksi pengolahan', 323),
(814, 'Seksi pemasaran ', 323),
(815, 'Seksi pengawasan keamanan produk hewan ', 324),
(816, 'Seksi pengawasan higlenis sanitasi dan RPH', 324),
(817, 'Seksi zoonosis dan kesejahteraan hewan ', 324),
(818, 'PTT', 31),
(819, 'Sub bagian program ', 326),
(820, 'Sub bagian keuangan ', 326),
(821, 'Sub bagian umum ', 326),
(822, 'Seksi pemetaan geologi dan air tanah ', 327),
(823, 'Seksi pengusahaan air tanah', 327),
(824, 'Seksi konservasi air tanah ', 327),
(825, 'Seksi pengusahaan mineral bukan logam dan batuan ', 328),
(826, 'Seksi pengusahaan mineral logam dan batu bara', 328),
(827, 'Seksi produksi, penjualan mineral dan batu bara ', 328),
(828, 'Seksi pengembangan energi baru terbarukan ', 329),
(829, 'Seksi pengusahaan energi baru terbarukan', 329),
(830, 'Seksi konservasi energi ', 329),
(831, 'Seksi pengembangan ketenagalistrikan ', 330),
(832, 'Seksi pengusahaan ketenagalistrikan', 330),
(833, 'Seksi pengawasan ketenagalistrikan ', 330),
(834, 'PTT', 32),
(835, 'Sub bagian program ', 332),
(836, 'Sub bagian keuangan', 332),
(837, 'Sub bagian umum ', 332),
(838, 'Seksi standarisasi dan tertib niaga ', 333),
(839, 'Seksi pemberdayaan konsumen ', 333),
(840, 'Seksi pengawasan barang beredar dan jasa ', 333),
(841, 'Seksi bina usaha dan pelaku distribusi ', 334),
(842, 'Seksi sarana distribusi dan logistik', 334),
(843, 'Seksi pemasaran produk dalam negeri ', 334),
(844, 'Seksi ekpor ', 335),
(845, 'Seksi impor', 335),
(846, 'Seksi pengembangan dan kerjasama ', 335),
(847, 'PTT', 33),
(848, 'Sub bagian program ', 337),
(849, 'Sub bagian keuangan ', 337),
(850, 'Sub bagian umum ', 337),
(851, 'Seksi industri hasil pertanian, hutan dan perekebunan dan', 338),
(852, 'Seksi industri makanan dan minuman, hasil laut, mesin,  periakanan dan peternakan ', 338),
(853, 'Seksi industri logam, mesin dan alat transportasi dan ', 339),
(854, 'Seksi industri elektronika dan telematika ', 339),
(855, 'Seksi industri kreatif ', 340),
(856, 'Seksi industri sandang dan kerajinan ', 340),
(857, 'PTT', 34),
(858, 'Sub bagian program ', 342),
(859, 'Sub bagian keuangan ', 342),
(860, 'Sub bagain umum ', 342),
(861, 'Seksi kewaspadaan dini ', 343),
(862, 'Seksi bimbingan dan penyuluhan ', 343),
(863, 'Seksi operasi dan pengendalian', 344),
(864, 'Seksi ketertiban umum ', 344),
(865, 'Seksi penegakan', 345),
(866, 'Seksi hubungan antar lembaga ', 345),
(867, 'Seksi data dan informasi', 346),
(868, 'Seksi pelatihan dan mobilisasi ', 346),
(869, 'PTT', 35),
(870, 'Sub bagian program ', 348),
(871, 'Sub bagian keuangan', 348),
(872, 'Sub bagian umum ', 348),
(873, 'Subbbidang perencanaan wilayah ', 349),
(874, 'Subbidang pekerjaan umum, pemukiman dan transportasi', 349),
(875, 'Subbidang kemaritiman dan sumber daya alam ', 349),
(876, 'Subbidang infestasi dan keuangan ', 350),
(877, 'Subbidang pangan dan pertanian', 350),
(878, 'Subbidang industri, perdagangan pariwisata ', 350),
(879, 'Subbidang sosial, ketenaga kerjaan dan kependududkan ', 351),
(880, 'Subbbidang pendidikan dan kesehatan', 351),
(881, 'Subbidang pemerintahan dan politik ', 351),
(882, 'Subbidang penelitian dan pengembangan ekonomi wilayah ', 352),
(883, 'subbidang penelitan dan pengembangan sosial budaya', 352),
(884, 'Subbidang penenlitian dan pengembangan informasi goespasial ', 352),
(885, 'Subbidang pemantauan, evaluasi dan pelaporan ', 353),
(886, 'Subbidang pengendalian perencanaan dan ', 353),
(887, 'Subbidang data dan sistem informasi perencanaan ', 353),
(888, 'PTT', 36),
(889, 'Sub bagian program ', 355),
(890, 'Sub bagain keuangan ', 355),
(891, 'Sub bagian umum ', 355),
(892, 'Sub bidang anggaran I ', 356),
(893, 'Sub bidang anggaran II', 356),
(894, 'Sub bidang evaluasi anggaran kabupaten/kota ', 356),
(895, 'Sub bidang kas ', 357),
(896, 'Sub bidang perbendaharaan I', 357),
(897, 'Sub bidang perbendaharaan II ', 357),
(898, 'Sub bidang Akuntansi I', 358),
(899, 'Sub bidang Akuntansi II', 358),
(900, 'Sub bidang pelaporan dan evaluasi keuangan daerah ', 358),
(901, 'Sub bidang perencanaan kebutuhan dan pengadaan BMD ', 359),
(902, 'Sub bidang pemeliharaan dan penghapusan BMD ', 359),
(903, 'Sub bidang penatausahaan dan pembinaan BMD ', 359),
(904, 'PTT', 37),
(905, 'kepala Sub bagian perelengkapan ', 361),
(906, 'Kepala sub bagian keuangan ', 361),
(907, 'Kepala Sub bagian umum dan kepegawaian ', 361),
(908, 'Sub bidang penyusunan program ', 362),
(909, 'Sub bidang pengembangan teknologi informasi penadapatan ', 362),
(910, 'Sub bidang analisis dan pelaporan ', 362),
(911, 'Sub bidang pajak kendaraan bermotor dan bea balik nama kendaraan bermotor ', 363),
(912, 'Sub bidang pajak daerah lainnya ', 363),
(913, 'Sub bidang administrasi dan pelayanan pajak daerah ', 363),
(914, 'Sub bidang retribusi ', 364),
(915, 'Sub bidang dana perimbangan ', 364),
(916, 'Sub bidang pendapatan lainnya ', 364),
(917, 'Sub bidang pengendalian ', 365),
(918, 'Sub bidang pembinaan ', 365),
(919, 'Sub bidang hukum dan sengketa pajak ', 365),
(920, 'PTT', 38),
(921, 'Kepala sub bagian perencanaan dan keuangan ', 367),
(922, 'Kepala sub bagian umum dan kepegawaian ', 367),
(923, 'Sub bidang sertifikasi kompetensi ', 368),
(924, 'Sub bidang pengeloloaan kelembagaan dan tenaga pengembangan kompetensi ', 368),
(925, 'Sub bidang pengelolaan sumber belajar dan kerasama ', 368),
(926, 'Sub bidang pengembangan kompetensi umum dan pilihan jabatan administrasi ', 369),
(927, 'Sub bidang pengembangan kompetensi jabatan adminiistrasi ', 369),
(928, 'Sub bidang penegmbangan kompetensi jabatan adaministrasi perangkat daerah penunjang ', 369),
(929, 'Sub bidang pengembangan kompetensi pimpinan Daerah dan jabatan pimpinan tinggi ', 370),
(930, 'Sub bidang pengembangan kompetensi jabatan fungsional ', 370),
(931, 'Sub bidang pengembangan kompetensi kepemimpinan dan prajabatan ', 370),
(932, 'PTT', 39),
(933, 'Subbag program dan Keuangan BKD', 372),
(934, 'Subbag Umum BKD', 372),
(935, 'Subbid Formasi dan Seleksi', 373),
(936, 'Subbid Pengangkatan dan Penggajian', 373),
(937, 'Subbid Pemindahan dan Pemberhentian', 373),
(938, 'Subbid Penempatan Jabatan', 374),
(939, 'Subbid Pendidikan dan Kesejahteraan Pegawai', 374),
(940, 'Subbid Pembinaan dan Evaluasi', 374),
(941, 'Subbid Dokumentasi dan Arsip Kepegawaian', 375),
(942, 'Subbid Pengolahan Data', 375),
(943, 'Subbid Penilaian Dan Informasi Kompetensi Pegawai', 375),
(944, 'PTT', 40),
(945, 'Subbag Program', 377),
(946, 'Subbag Keuangan', 377),
(947, 'Subbag Umum', 377),
(948, 'Seksi Pencegahan', 378),
(949, 'Seksi Kesiapsiagaan', 378),
(950, 'Seksi Tanggap Darurat', 379),
(951, 'Seksi Penyelamatan dan Evakuasi', 379),
(952, 'Seksi Rehabilitasi', 380),
(953, 'Seksi Rekonstruksi', 380),
(954, 'PTT', 41),
(955, 'Sub Bagian Tata Usaha', 42),
(956, 'Seksi Hubungan Antar Lembaga', 42),
(957, 'Seksi Pelayanan Umum', 42),
(958, 'Seksi Promosi dan Informasi', 42),
(959, 'PTT', 42);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `unit_id` smallint(6) NOT NULL,
  `role_id` smallint(6) NOT NULL,
  `status_id` smallint(6) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `unit_id`, `role_id`, `status_id`, `created_at`, `updated_at`) VALUES
(2, 'yasrul', 'UqzdPXfxR1V_AsgDagf2BGnTjsBGrJDQ', '$2y$13$uh7OXxGwgwHgkicXhO3tfex7IOimuILC2s.WgdfrqwENDjR6n099G', NULL, 'yasrul93@gmail.com', 3, 2, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'amiruddin', 'IvGFzQ3uvJPi_P3JmqKEXdK0V9YYF7St', '$2y$13$ArWhFm0bGSl9jpZF/xIH1.hqboi..Fi0/oz59JQXnkl4OyArqWzA.', NULL, 'amir@ntbprov.go.id', 3, 2, 1, '0000-00-00 00:00:00', '2018-02-15 10:34:57'),
(6, 'Administrator', 'N5yGLBNsIa7oyk35Eq3wiBfZW9cq0Ynp', '$2y$13$QjgGiHcANDFYU5bURinx0Oj3fLE7mLFp9cVyLkAc5w39Kd72IS.xu', NULL, 'yasrul@gmail.com', 5, 3, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'abdullah', '6URjxAyu8dR9n9x_5JYnc68Im6eKhMoY', '$2y$13$xx87TaYGKgmA.ZRRSvUDEuhWtyo9Qs1NyHe4WYKl8buRmZ6v1Og3y', NULL, 'abdullah@gmail.com', 4, 2, 1, '0000-00-00 00:00:00', '2018-02-15 10:35:21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `disposisi`
--
ALTER TABLE `disposisi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_regin` (`id_surat`),
  ADD KEY `id_pemberi` (`id_pemberi`);

--
-- Indexes for table `disposisi_tujuan`
--
ALTER TABLE `disposisi_tujuan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gender`
--
ALTER TABLE `gender`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kecepatan_sampai`
--
ALTER TABLE `kecepatan_sampai`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gender_id_idx` (`gender_id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `status_akses`
--
ALTER TABLE `status_akses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `status_reg`
--
ALTER TABLE `status_reg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `status_surat`
--
ALTER TABLE `status_surat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `status_tujuan`
--
ALTER TABLE `status_tujuan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `status_user`
--
ALTER TABLE `status_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `surat`
--
ALTER TABLE `surat`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kecepatan_tanggapan` (`kecepatan_sampai`),
  ADD KEY `tingkat_keamanan` (`tingkat_keamanan`),
  ADD KEY `id_pengirim` (`id_pengirim`);

--
-- Indexes for table `surat_tujuan`
--
ALTER TABLE `surat_tujuan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tingkat_keamanan`
--
ALTER TABLE `tingkat_keamanan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unit_kerja`
--
ALTER TABLE `unit_kerja`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `password_reset_token` (`password_reset_token`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `disposisi`
--
ALTER TABLE `disposisi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `disposisi_tujuan`
--
ALTER TABLE `disposisi_tujuan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gender`
--
ALTER TABLE `gender`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `kecepatan_sampai`
--
ALTER TABLE `kecepatan_sampai`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `status_akses`
--
ALTER TABLE `status_akses`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `status_surat`
--
ALTER TABLE `status_surat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `status_tujuan`
--
ALTER TABLE `status_tujuan`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `status_user`
--
ALTER TABLE `status_user`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `surat`
--
ALTER TABLE `surat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `surat_tujuan`
--
ALTER TABLE `surat_tujuan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `tingkat_keamanan`
--
ALTER TABLE `tingkat_keamanan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `profile`
--
ALTER TABLE `profile`
  ADD CONSTRAINT `gender_id_fk` FOREIGN KEY (`gender_id`) REFERENCES `gender` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
