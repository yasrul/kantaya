-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 20, 2016 at 08:40 AM
-- Server version: 5.5.53-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `kantaya`
--

-- --------------------------------------------------------

--
-- Table structure for table `disposisi`
--

CREATE TABLE IF NOT EXISTS `disposisi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_regin` int(11) NOT NULL,
  `id_pemberi` int(11) NOT NULL,
  `tgl_disposisi` datetime NOT NULL,
  `tgl_selesai` datetime DEFAULT NULL,
  `id_intruksi` tinyint(4) NOT NULL,
  `pesan` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_regin` (`id_regin`),
  KEY `id_pemberi` (`id_pemberi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `disposisi_det`
--

CREATE TABLE IF NOT EXISTS `disposisi_det` (
  `id_disposisi` int(11) NOT NULL,
  `id_penerima` smallint(6) NOT NULL,
  `tgl_diterima` datetime DEFAULT NULL,
  KEY `id_disposisi` (`id_disposisi`),
  KEY `id_penerima` (`id_penerima`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ekspedisi`
--

CREATE TABLE IF NOT EXISTS `ekspedisi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_surat` int(11) NOT NULL,
  `tgl_kirim` datetime NOT NULL,
  `id_pengirim` smallint(6) NOT NULL,
  `id_sup` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_surat` (`id_surat`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ekspedisi_det`
--

CREATE TABLE IF NOT EXISTS `ekspedisi_det` (
  `id_eks` int(11) NOT NULL,
  `id_tujuan` int(11) NOT NULL,
  `tgl_diterima` datetime DEFAULT NULL,
  `is_eksis` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gender`
--

CREATE TABLE IF NOT EXISTS `gender` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `gender_name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `gender`
--

INSERT INTO `gender` (`id`, `gender_name`) VALUES
(1, 'male'),
(2, 'female');

-- --------------------------------------------------------

--
-- Table structure for table `kecepatan_tanggapan`
--

CREATE TABLE IF NOT EXISTS `kecepatan_tanggapan` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `nama_kecepatan` varchar(50) NOT NULL,
  `nilai_kecepatan` smallint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1436495090),
('m130524_201442_init', 1436495111);

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `first_name` text,
  `last_name` text,
  `birthdate` date DEFAULT NULL,
  `gender_id` smallint(5) unsigned NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gender_id_idx` (`gender_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`id`, `user_id`, `first_name`, `last_name`, `birthdate`, `gender_id`, `created_at`, `updated_at`) VALUES
(1, 1, 'Yasrul', 'Abdullah', '1974-02-03', 1, '2015-07-30 16:21:39', '2015-07-30 16:21:39'),
(2, 3, 'Abdullah', 'Rawahah', '1979-05-16', 1, '2015-07-30 16:23:56', '2015-07-30 16:23:56'),
(3, 4, 'Fatimah', 'Sholihah', '1978-05-17', 2, '2015-07-30 16:25:15', '2015-07-30 16:25:15'),
(4, 5, 'Hamzah', 'Namira', '1980-08-27', 1, '2015-08-03 09:51:06', '2015-08-03 09:51:06');

-- --------------------------------------------------------

--
-- Table structure for table `regin`
--

CREATE TABLE IF NOT EXISTS `regin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_unit` smallint(6) NOT NULL,
  `id_surat` int(11) NOT NULL,
  `no_agenda` varchar(30) DEFAULT NULL,
  `kode` varchar(10) DEFAULT NULL,
  `tgl_terima` datetime DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_unit` (`id_unit`),
  KEY `id_surat` (`id_surat`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `regout`
--

CREATE TABLE IF NOT EXISTS `regout` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_unit` smallint(6) NOT NULL,
  `id_surat` int(11) NOT NULL,
  `tgl_kirim` datetime DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_unit` (`id_unit`),
  KEY `id_surat` (`id_surat`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE IF NOT EXISTS `role` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(45) NOT NULL,
  `role_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `role_name`, `role_value`) VALUES
(1, 'User', 10),
(2, 'Operator', 20),
(3, 'AdminSystem', 30);

-- --------------------------------------------------------

--
-- Table structure for table `status_surat`
--

CREATE TABLE IF NOT EXISTS `status_surat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status_name` varchar(50) NOT NULL,
  `status_value` smallint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `status_tujuan`
--

CREATE TABLE IF NOT EXISTS `status_tujuan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status_name` varchar(30) NOT NULL,
  `status_value` smallint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `status_user`
--

CREATE TABLE IF NOT EXISTS `status_user` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `status_name` varchar(45) NOT NULL,
  `status_value` smallint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `status_user`
--

INSERT INTO `status_user` (`id`, `status_name`, `status_value`) VALUES
(1, 'Active', 10),
(2, 'Pending', 5);

-- --------------------------------------------------------

--
-- Table structure for table `surat`
--

CREATE TABLE IF NOT EXISTS `surat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no_surat` varchar(255) NOT NULL,
  `tgl_surat` date NOT NULL,
  `perihal` varchar(255) NOT NULL,
  `lampiran` varchar(100) DEFAULT NULL,
  `kecepatan_tanggapan` smallint(6) DEFAULT NULL,
  `tingkat_keamanan` smallint(6) DEFAULT NULL,
  `file_arsip` varchar(255) DEFAULT NULL,
  `id_pengirim` smallint(6) DEFAULT NULL,
  `pengirim_manual` varchar(100) DEFAULT NULL,
  `alamat_manual` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kecepatan_tanggapan` (`kecepatan_tanggapan`),
  KEY `tingkat_keamanan` (`tingkat_keamanan`),
  KEY `id_pengirim` (`id_pengirim`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tingkat_keamanan`
--

CREATE TABLE IF NOT EXISTS `tingkat_keamanan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_tingkat` varchar(50) NOT NULL,
  `nilai_tingkat` smallint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tujuan_surat`
--

CREATE TABLE IF NOT EXISTS `tujuan_surat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_surat` int(11) NOT NULL,
  `id_penerima` int(11) DEFAULT NULL,
  `penerima_manual` varchar(255) DEFAULT NULL,
  `alamat_manual` varchar(255) DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_surat` (`id_surat`),
  KEY `id_penerima` (`id_penerima`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `unit_kerja`
--

CREATE TABLE IF NOT EXISTS `unit_kerja` (
  `id` smallint(6) NOT NULL,
  `unit_kerja` varchar(255) NOT NULL,
  `id_induk` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `role_id` smallint(6) NOT NULL,
  `status_id` smallint(6) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `password_reset_token` (`password_reset_token`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `role_id`, `status_id`, `created_at`, `updated_at`) VALUES
(2, 'yasrul', 'UqzdPXfxR1V_AsgDagf2BGnTjsBGrJDQ', '$2y$13$uh7OXxGwgwHgkicXhO3tfex7IOimuILC2s.WgdfrqwENDjR6n099G', NULL, 'yasrul93@gmail.com', 3, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'amiruddin', 'IvGFzQ3uvJPi_P3JmqKEXdK0V9YYF7St', '$2y$13$ArWhFm0bGSl9jpZF/xIH1.hqboi..Fi0/oz59JQXnkl4OyArqWzA.', NULL, 'amir@ntbprov.go.id', 4, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 'Administrator', 'N5yGLBNsIa7oyk35Eq3wiBfZW9cq0Ynp', '$2y$13$QjgGiHcANDFYU5bURinx0Oj3fLE7mLFp9cVyLkAc5w39Kd72IS.xu', NULL, 'yasrul@gmail.com', 3, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'abdullah', '6URjxAyu8dR9n9x_5JYnc68Im6eKhMoY', '$2y$13$xx87TaYGKgmA.ZRRSvUDEuhWtyo9Qs1NyHe4WYKl8buRmZ6v1Og3y', NULL, 'abdullah@gmail.com', 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `profile`
--
ALTER TABLE `profile`
  ADD CONSTRAINT `gender_id_fk` FOREIGN KEY (`gender_id`) REFERENCES `gender` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
